import React from "react";

// Component
import CoursesList from "./list/CoursesList";

function UserCoursesPage() {
    return (
        <>
            <CoursesList />
        </>
    );
}

export default UserCoursesPage;
